from data.credentials import DBCredentials
import requests
import json

CRED = DBCredentials()


def lambda_handler(event, context):
    response = requests.get("https://www.example.com/")
    print(response.text)
    return response.text

lambda_handler(1,1)